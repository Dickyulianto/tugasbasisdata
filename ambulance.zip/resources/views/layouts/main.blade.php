<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Ambulcance | {{ $title }}</title>
    <link rel="shortcut icon" type="image/icon" href="css/1.png"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/94ef7dcb87.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <script src="java/main.js"></script>
    <link href="https://fonts.googleapis.com/css? family=Varela+Round" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Nunito" />
  </head>
  <body>
    
    @include('partials.navbar')

    <div class="main">
        @yield('container')
    </div>

    <a class="gotopbtn js-scroll-trigger" href="#page-top"><i class="fa-solid fa-arrow-up rounded-cicrle"></i></a>
    
    <script src="java/main.js"></script>
    <script src="java/form.js"></script>
  </body>
</html>