<?php $__env->startSection('container'); ?>


<header class="masthead">
    <div id="page-top" class="container d-flex h-100 align-items-center">
      <div class="mx-auto text-center">
        <h1 class="mx-auto my-0 text-uppercase">My Ambulance Care</h1>
        <h2 class="text-white-50 mx-auto mt-2 mb-5">Relawan Ambulance Pembuka Harapan</h2>
        <a href="/form" class="btn btn-primary js-scroll-trigger">Butuh Bantuan</a>
      </div>
    </div>
  </header>

  
  <section id="about" class="about-section text-center">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2 class="text-white mb-4">Tujuan dan Cita-Cita Kami</h2>
          <hr class="accessory">
          <p class="text-white-50">Program pelayanan tanggap darurat kebutuhan transportasi dalam upaya penanganan kasus kesehatan dan kematian bagi kaum dhuafa, layanan ini di berikan secara gratis bagi mereka yang membutuhkan.
            Program Ambulan gratis diharapkan mampu menyelesaikan masalah mustahik saat tertimpa mushibah sehingga tidak menambah beban duka yang sedang mereka alami.</p>
          <img src='https://i.postimg.cc/tT1jrQqW/1.png' class="col-lg-6 img-fluid unionicon" alt=""> <img src="https://i.postimg.cc/nVB8M1CF/2.png" class="col-lg-6 img-fluid cresticon" alt="">

          <p class="text-white-50">Tujuan Penggunaannya adalah Pengangkutan penderita yang tidak memerlukan perawatan khusus/ tindakan darurat untuk menyelamatkan nyawa dan diperkirakan tidak akan timbul kegawatan selama dalam perjalanan.</p>

          <h3 class="text-white mb-4">Team A Basis Data</h3>

          <hr class="accessory" width="50%">
          <br>

        </div>
      </div>

      <!-- Headshots -->
      <div class="container-fluid">

        <!-- Row 1 -->
        <div class="row headshots">

          <div class="col-sm-2">

            <figure class="one">
              <img src='https://i.postimg.cc/tCfL09VW/femaleheadshot.jpg' class="headshotphoto" />
              <p class="text-white headshottext">Dicky Eko</p>
              <p class="text-white headshotgrade"> <b>NIM</b>: 21330057</p>
              <p class="text-white headshotgrade"> <b>Jurusan</b>: Teknik Informatika </p>
              <p class="text-white headshotgrade"> <b>Matkul</b>: Pemrograman Basis Data</p>
            </figure>

          </div>

          <div class="col-sm-2">

            <figure class="one">
              <img src='https://i.postimg.cc/CxCTbWz8/maleheadshot.jpg' class="headshotphoto" />
              <p class="text-white headshottext">Rezky</p>
              <p class="text-white headshotgrade"> <b>NIM</b>: 21330057</p>
              <p class="text-white headshotgrade"> <b>Jurusan</b>: Teknik Informatika </p>
              <p class="text-white headshotgrade"> <b>Matkul</b>: Pemrograman Basis Data</p>
            </figure>

          </div>

          <div class="col-sm-2">

            <figure class="one">
              <img src='https://i.postimg.cc/tCfL09VW/femaleheadshot.jpg' class="headshotphoto" />
              <p class="text-white headshottext">Yohanes</p>
              <p class="text-white headshotgrade"> <b>NIM</b>: 21330057</p>
              <p class="text-white headshotgrade"> <b>Jurusan</b>: Teknik Informatika </p>
              <p class="text-white headshotgrade"> <b>Matkul</b>: Pemrograman Basis Data</p>

            </figure>

          </div>

          <div class="col-sm-2">

            <figure class="one">
              <img src='https://i.postimg.cc/CxCTbWz8/maleheadshot.jpg' class="headshotphoto" />
              <p class="text-white headshottext">Annisa Eka</p>
              <p class="text-white headshotgrade"> <b>NIM</b>: 21330057</p>
              <p class="text-white headshotgrade"> <b>Jurusan</b>: Teknik Informatika </p>
              <p class="text-white headshotgrade"> <b>Matkul</b>: Pemrograman Basis Data</p>
            </figure>

          </div>

          <div class="col-sm-3">

            <figure class="one">
              <img src='https://i.postimg.cc/CxCTbWz8/maleheadshot.jpg' class="headshotphoto" />
              <p class="text-white headshottext">Ridho Gilang</p>
              <p class="text-white headshotgrade"> <b>NIM</b>: 21330057</p>
              <p class="text-white headshotgrade"> <b>Jurusan</b>: Teknik Informatika </p>
              <p class="text-white headshotgrade"> <b>Matkul</b>: Pemrograman Basis Data</p>
            </figure>

          </div>

        </div>

      </div> <br><br>

    </div>
    <!-- Container div -->

  </section>

  
  <section id="projects" class="projects-section">
    <div class="container-fluit">
          <h2 class="text-black mb-4">Temukan Relawan Kami</h2>
          <hr class="accessory" width="50%">
        <div class="relawan">
          <img src="https://i.postimg.cc/zDw9NSd9/peta.gif" alt="">
        </div>
    </div>
  </section>

  
  <section id="signup" class="signup-section">
    <div class="container">
      <div class="row">
        <div class="col-md-10 col-lg-8 mx-auto text-center">

          <i class="far fa-paper-plane fa-2x mb-2 text-white"></i>
          <h2 class="text-white mb-5">Submit your email for news & event updates!</h2>

          <form class="form-inline d-flex">
            <input type="email" class="form-control flex-fill mr-0 mr-sm-2 mb-3 mb-sm-0" id="inputEmail" placeholder="Enter email address...">
            <button type="submit" class="btn btn-primary mx-auto">Subscribe</button>
          </form>

        </div>
      </div>
    </div>
  </section>

  
  <section class="contact-section bg-black">
    <div class="container">

      <div class="row">

        <div class="col-md-4 mb-3 mb-md-0">
          <div class="card py-4 h-100">
            <div class="card-body text-center">
              <i class="fas fa-map-marked-alt text-primary mb-2"></i>
              <h4 class="text-uppercase m-0">Alamat Kami</h4>
              <hr class="my-4">
              <div class="small text-black-50">Universitas Janabadra Fakultas Teknik</div>
            </div>
          </div>
        </div>

        <div class="col-md-4 mb-3 mb-md-0">
          <div class="card py-4 h-100">
            <div class="card-body text-center">
              <i class="fas fa-envelope text-primary mb-2"></i>
              <h4 class="text-uppercase m-0">Email</h4>
              <hr class="my-4">
              <div class="small text-black-50">
                <a href="#">teamabasisdata@gmail.com</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4 mb-3 mb-md-0">
          <div class="card py-4 h-100">
            <div class="card-body text-center">
              <i class="fas fa-mobile-alt text-primary mb-2"></i>
              <h4 class="text-uppercase m-0">Telepon</h4>
              <hr class="my-4">
              <div class="small text-black-50">+62 (882) 2772-8073</div>
            </div>
          </div>
        </div>
      </div>

      <div class="social d-flex justify-content-center">
        <a href="" class="mx-2">
            <i class="fab fa-instagram"></i>
          </a>
        <a href="" class="mx-2">
            <i class="fab fa-facebook-f"></i>
          </a>
        <a href="" class="mx-2">
            <i class="fab fa-twitter"></i>
          </a>
      </div>

    </div>
  </section>

  
  <footer class="bg-black small text-center text-white-50">
    <div class="container">
      Hak Cipta &copy; Team A Basis Data 2022
    </div>
  </footer>

  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel project\ambulance\resources\views/home.blade.php ENDPATH**/ ?>