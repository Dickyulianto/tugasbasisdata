(function($) {
    "use strict"; 
    // Pengguliran halus menggunakan pelonggaran jQuery
    $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
      if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {
        var target = $(this.hash);
        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
        if (target.length) {
          $('html, body').animate({
            scrollTop: (target.offset().top - 70)
          }, 1000, "easeInOutExpo");
          return false;
        }
      }
    });
  
    // Menutup menu responsif ketika tautan pemicu gulir diklik
    $('.js-scroll-trigger').click(function() {
      $('.navbar-collapse').collapse('hide');
    });
  
    $('.js-scroll-trigger').click(function() {
      $('.btn-collapse').collapse('hide');
    });
  
    // Aktifkan scrollspy untuk menambahkan kelas aktif ke item navbar di scroll
    $('body').scrollspy({
      target: '#mainNav',
      offset: 100
    });
  
    // Ciutkan Navbar
    var navbarCollapse = function() {
      if ($("#mainNav").offset().top > 100) {
        $("#mainNav").addClass("navbar-shrink");
      } else {
        $("#mainNav").removeClass("navbar-shrink");
      }
    };
    // Ciutkan sekarang jika halaman tidak berada di atas
    navbarCollapse();
    // Perkecil bilah navigasi saat halaman digulir
    $(window).scroll(navbarCollapse);
  
  })(jQuery); // Akhir penggunaan 